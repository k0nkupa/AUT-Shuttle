//
//  ViewController.swift
//  AUT Shuttle
//
//  Created by The Ton Le on 2/08/18.
//  Copyright © 2018 The Ton Le. All rights reserved.
//

import UIKit
import Alamofire
import SystemConfiguration
import ProgressHUD

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Get buses routes
        getRoutes()
        
        //Check if device connect to network or not
        if Reachability.isConnectedToNetwork() {
            getDetail()
        } else {
            if UserDefaults.standard.getIsConnectedNetwork() == false {
                let settingController = SettingController()
                settingController.logOut()
            }
        }
        
        usernameTextField.delegate = self
        passwordTextField.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if UserDefaults.standard.isLoggedIn() {
            showMenuScreen()
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Return key to hide keyboard
    /*******************************************************************/
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //MARK: - Log In Button Function
    /*******************************************************************/
    
    @IBAction func logInButton(_ sender: Any) {
        login()
        ProgressHUD.show("Loading")
        ProgressHUD.spinnerColor(UIColor.blue)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
            if UserDefaults.standard.getToken().isEmpty { //Wrong username or password
                ProgressHUD.showError("Wrong Username or Password!")
            } else {
                ProgressHUD.dismiss()
                self.getDetail()
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
                    if UserDefaults.standard.getQRCode().isEmpty {
                        ProgressHUD.show("Loading")
                        ProgressHUD.spinnerColor(UIColor.blue)
                    } else {
                        UserDefaults.standard.setLoggedIn(val: true)
                        ProgressHUD.dismiss()
                        self.showMenuScreen()
                    }
                }//End Dispatch 2
            }//End else
        }//End Dispatch 1
    }
    
    //MARK: - Log In Function
    /*******************************************************************/
    
    func login() {
        let url = String(format: "https://dev-api.tessera-dev.haydenwoodhead.com/api/v1/users/authtokens/")
        let username: String = usernameTextField.text!
        let password: String = passwordTextField.text!
        let parameters: Parameters = [
            "username": username,
            "password": password
        ]
        Alamofire.request(url, method: .post, parameters: parameters).validate(statusCode: 200..<300).responseJSON { (response) in
            if let tokenJSON = response.result.value {
                let tokenObject: Dictionary = tokenJSON as! Dictionary<String, Any>
                let token: String = tokenObject["token"] as! String
                UserDefaults.standard.setToken(token: token)
            }else {
                let token = ""
                UserDefaults.standard.setToken(token: token)
            }
        }
    }
    
    //MARK: - get User Detail
    /*******************************************************************/
    
    func getDetail() {
        
//        let isOnline = false
        
        //Set the header
        let headers: HTTPHeaders = [
            "Authorization": "Token \(UserDefaults.standard.getToken())",
            "Accept": "application/json"
        ]
        
        Alamofire.request("https://dev-api.tessera-dev.haydenwoodhead.com/api/v1/users/tickets/", headers: headers).responseJSON { response in
            if let qrJSON = response.result.value {
                let qrObject: Dictionary = qrJSON as! Dictionary<String, Any>
                let qr: String = qrObject["qr_code"] as! String
                let current_value: Int = qrObject["current_value"] as! Int
                let datetime: Int = qrObject["ttl"] as! Int
                
                //Set the ttl
                self.dateFormat(datetime: datetime)
                
                // Set user details to the UserDefaults
                UserDefaults.standard.setQRCode(qrcode: qr)
                UserDefaults.standard.setValue(val: current_value)
            }
        }
    }
    
    //MARK: - get Routes
    /*******************************************************************/
    
    func getRoutes() {
        let url = URL(string: "https://dev-api.tessera-dev.haydenwoodhead.com/api/v1/users/routes/")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do {
                let routes = try JSONDecoder().decode([Route].self, from: data!)
                Routes2.routesArr = routes
            } catch {
                ProgressHUD.showError("Error")
            }
            }.resume()
    }
    
    //MARK: - show Menu screen
    /*******************************************************************/
    
    func showMenuScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "menuScreen") as! UITabBarController
        //Show tab bar controller
        self.showDetailViewController(vc, sender: (Any).self)
    }
    
    //MARK: - Date Format
    /*******************************************************************/
    func dateFormat(datetime: Int) {
        //Date Format
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        
        //Get Today
        let dateNow = Date()
        let dateNowFormatted = formatter.string(from: dateNow)
        
        //Format the TTL to readable format
        let localDate = Date(timeIntervalSince1970: TimeInterval(datetime))
        let dateExpire = formatter.string(from: localDate)
        
        //Set the TTL to UserDefault
        UserDefaults.standard.setDateTimeExpire(datetime: dateExpire)
        
        //Compare current date and the ttl
        if dateNowFormatted >= dateExpire {
            let isConnected = false
            UserDefaults.standard.setIsConnectedNetwork(isConnected: isConnected)
        } else {
            let isConnected = true
            UserDefaults.standard.setIsConnectedNetwork(isConnected: isConnected)
        }
        
        
    }
    
    //MARK: - Check for Internet Connection
    /*******************************************************************/
    
    public class Reachability {
        
        class func isConnectedToNetwork() -> Bool {
            
            var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
            zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
            zeroAddress.sin_family = sa_family_t(AF_INET)
            
            let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                    SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
                }
            }
            
            var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
            if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
                return false
            }
            
            /* Only Working for WIFI
             let isReachable = flags == .reachable
             let needsConnection = flags == .connectionRequired
             
             return isReachable && !needsConnection
             */
            
            // Working for Cellular and WIFI
            let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
            let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
            let ret = (isReachable && !needsConnection)
            
            return ret
            
        }
    }
}

