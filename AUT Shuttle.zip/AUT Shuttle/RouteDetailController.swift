//
//  RouteDetailController.swift
//  AUT Shuttle
//
//  Created by The Ton Le on 25/08/18.
//  Copyright © 2018 The Ton Le. All rights reserved.
//

import Foundation
import UIKit

class RouteDetailController: UIViewController {
    
    
    @IBOutlet weak var routeName: UILabel!
    @IBOutlet weak var routeDescription: UILabel!
    @IBOutlet weak var routeCost: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        routeName.text = Routes2.routesArr[myIndex].name
        routeDescription.text = Routes2.routesArr[myIndex].description
        routeCost.text = String(Routes2.routesArr[myIndex].cost)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
